package mounica.sringframework.spring5webApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5webAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5webAppApplication.class, args);
	}

}
