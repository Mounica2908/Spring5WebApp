package mounica.sringframework.spring5webApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring5webAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
